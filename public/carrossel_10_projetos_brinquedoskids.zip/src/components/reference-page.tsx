import { useEffect, useRef, useState } from "react";

const previews = Array.from({ length: 10 }, (_, i) =>
  `/projetos-reciclaveis/projeto-${String(i + 1).padStart(2, "0")}.webp`
);

function replacePreviewCarousel(root: HTMLElement) {
  const title = Array.from(root.querySelectorAll("h2")).find(
    (el) => el.textContent?.trim().toLowerCase() === "veja algumas páginas por dentro"
  );
  if (!title) return false;
  const header = title.parentElement;
  if (!header) return false;

  // Use only the two carousel rows directly following this heading.
  const tracks: HTMLElement[] = [];
  let sibling = header.nextElementSibling;
  for (let i = 0; sibling && i < 4 && tracks.length < 2; i++, sibling = sibling.nextElementSibling) {
    const track = sibling.querySelector<HTMLElement>("div[style*='animation']");
    if (track && track.querySelectorAll("img").length >= 2) tracks.push(track);
  }
  if (tracks.length < 2) return false;
  tracks.slice(0, 2).forEach((track, rowIndex) => {
    const images = Array.from(track.querySelectorAll<HTMLImageElement>("img"));
    if (!images.length) return;
    const row = previews.slice(rowIndex * 5, rowIndex * 5 + 5);
    // Duplicate the five previews for seamless CSS -50% continuous looping.
    const sourceCards = images.slice(0, 5).map((img) => img.parentElement);
    if (sourceCards.some((item) => !item)) return;
    track.replaceChildren(...[...sourceCards, ...sourceCards].map((card, n) => {
      const copy = card!.cloneNode(true) as HTMLElement;
      const img = copy.querySelector("img")!;
      img.src = row[n % 5];
      img.alt = `Projeto criativo com materiais recicláveis ${rowIndex * 5 + n % 5 + 1}`;
      img.loading = "lazy";
      img.decoding = "async";
      return copy;
    }));
  });
  return true;
}

export function ReferencePage() {
  const container = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let cancelled = false;
    let unmount: (() => void) | undefined;
    let observer: MutationObserver | undefined;
    const moduleUrl = new URL("/reference/site.js", window.location.origin).href;
    import(/* @vite-ignore */ moduleUrl)
      .then((module) => {
        if (!cancelled && container.current) {
          unmount = module.mountReferencePage(container.current);
          observer = new MutationObserver(() => {
            if (container.current && replacePreviewCarousel(container.current)) observer?.disconnect();
          });
          observer.observe(container.current, { childList: true, subtree: true });
          replacePreviewCarousel(container.current);
        }
      })
      .catch(() => { if (!cancelled) setFailed(true); });
    return () => { cancelled = true; observer?.disconnect(); unmount?.(); };
  }, []);
  return <>
    <div ref={container} />
    {failed && <p role="alert">Não foi possível carregar a página. <a href="/">Tentar novamente</a></p>}
  </>;
}
